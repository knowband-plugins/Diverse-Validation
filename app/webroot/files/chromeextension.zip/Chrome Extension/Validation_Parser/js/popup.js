// This callback function is called when the content script has been 
// injected and returned its results
function onPageDetailsReceived(pageDetails)  { 
    //document.getElementById('title').value = pageDetails.title; 
    //document.getElementById('url').value = pageDetails.url; 
	document.getElementById('velocityContentField').innerText = pageDetails.summary; 
} 

// Global reference to the status display SPAN
var statusDisplay = null;

function parseHtmlServer() {
    //event.preventDefault();
	return true;
}

function clearVelocityValidation() {
	event.preventDefault();
	chrome.tabs.executeScript(null, { file: "js/jquery-3.2.1.min.js" }, function() {
		chrome.tabs.executeScript(null, { file: "js/clear.js" });
	});
}

// POST the data to the server using XMLHttpRequest
function parseHtml() {
    // Cancel the form submit
    event.preventDefault();
    $('#validation_loader').show();
    // The URL to POST our data to
//    var postUrl = 'http://localhost.com/diverse/validation/api';
    var postUrl = 'http://diverse.velsof.com/validation/api';
    

    // Set up an asynchronous AJAX POST request
    var xhr = new XMLHttpRequest();
    xhr.open('POST', postUrl, true);
    
    // Prepare the data to be POSTed by URLEncoding each field's contents
    //var title = encodeURIComponent(document.getElementById('title').value);
    //var url = encodeURIComponent(document.getElementById('url').value);
    var summary = encodeURIComponent(document.getElementById('velocityContentField').value);
    //var tags = encodeURIComponent(document.getElementById('tags').value);
    
    var params = 'content=' + summary;
    
    // Replace any instances of the URLEncoded space char with +
    params = params.replace(/%20/g, '+');

    xhr.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
    // Handle request state change events
    xhr.onreadystatechange = function() { 
        // If the request completed
        if (xhr.readyState == 4) {
            if (xhr.status == 200) {
				
				var jsonResponse = JSON.parse(xhr.responseText);
				chrome.tabs.executeScript(null, { file: "js/jquery-3.2.1.min.js" }, function() {
					chrome.tabs.executeScript(null, { code: 'var config = ' + JSON.stringify(jsonResponse) }, function() {
                                                $('#validation_loader').hide();
						chrome.tabs.executeScript(null, { file: "js/custom.js" });
					});
				});
				//alert(jsonResponse)
                //window.setTimeout(window.close, 1000);
            } else {
                // Show what went wrong
                //statusDisplay.innerHTML = 'Error saving: ' + xhr.statusText;
            }
        }
    };

    // Send the request and set status
//    $('#validation_loader').hide();
    xhr.send(params);
    //statusDisplay.innerHTML = 'Saving...';
}

// When the popup HTML has loaded
window.addEventListener('load', function(evt) {
    // Cache a reference to the status display SPAN
    //statusDisplay = document.getElementById('status-display');
    document.getElementById('validateLocal').addEventListener('click', parseHtml);
    document.getElementById('validateServer').addEventListener('click', parseHtmlServer);
    document.getElementById('clearValidation').addEventListener('click', clearVelocityValidation);
	
    // Get the event page
    chrome.runtime.getBackgroundPage(function(eventPage) {
        // Call the getPageInfo function in the event page, passing in 
        // our onPageDetailsReceived function as the callback. This injects 
        // content.js into the current tab's HTML
        eventPage.getPageDetails(onPageDetailsReceived);
    });
});